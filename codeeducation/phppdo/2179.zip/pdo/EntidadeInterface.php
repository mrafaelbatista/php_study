<?php

interface EntidadeInterface
{
    public function getId();
    public function setId($id);

    public function getTable();
    public function setTable($table);
}