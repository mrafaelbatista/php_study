<?php

try {
    $conexao = new \PDO("mysql:host=localhost;dbname=pdo","root","root");

    #$query = "Insert into clientes(nome,email) values('Pedro','pedro@wesley.com.br');";
    $query = "Select * from clientes where id= :id";

    $stmt = $conexao->prepare($query);
    $stmt->bindValue(":id", $_GET['id'], PDO::PARAM_INT);
    $stmt->execute();



    print_r($stmt->fetch(PDO::FETCH_ASSOC));

}
catch(\PDOException $e) {
    echo "Não foi possível estabelecer a conexão com o banco de dados: Erro código: ".$e->getCode().": ".$e->getMessage();
}

